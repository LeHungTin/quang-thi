/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import entities.Product;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Admin
 */
@Local
public interface ProductBeanLocal {
    public List<Product> getAllProducts();
    public boolean insertProduct(Product p);
    public boolean updateProduct(Product p);
    public boolean deleteProduct(Integer proId);
    public List<Product> getProductByProductName(String proName);
    public Product getProductById(Integer proId);
}
