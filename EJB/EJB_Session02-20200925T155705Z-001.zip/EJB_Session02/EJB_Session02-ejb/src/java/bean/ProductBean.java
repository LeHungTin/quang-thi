/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import dao.ProductDAOImpl;
import entities.Product;
import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author Admin
 */
@Stateless
public class ProductBean implements ProductBeanLocal {

    @Override
    public List<Product> getAllProducts() {
        return new ProductDAOImpl().getAllProducts();
    }

    @Override
    public boolean insertProduct(Product p) {
        return new ProductDAOImpl().insertProduct(p);
    }

    @Override
    public boolean updateProduct(Product p) {
        return new ProductDAOImpl().updateProduct(p);
    }

    @Override
    public boolean deleteProduct(Integer proId) {
        return new ProductDAOImpl().deleteProduct(proId);
    }

    @Override
    public List<Product> getProductByProductName(String proName) {
        return new ProductDAOImpl().getProductByProductName(proName);
    }

    @Override
    public Product getProductById(Integer proId) {
        return new ProductDAOImpl().getProductById(proId);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
